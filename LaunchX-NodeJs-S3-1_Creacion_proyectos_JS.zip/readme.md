# 📒 Repo Misión Backend(NodeJs)| Semana 3| Proyecto 1: my_launchx_app | Creación de Proyectos en JS 

## ⌨ Descripción
Creación de un proyecto JS, agregando clases y Unit Testing con técnica TDD.



📎 Enlace de todos los proyectos de Semana 3:
`https://github.com/antoni-codes/playbook/tree/main/weekly_mission_3`


