class MissionCommander {
    constructor(name){
        this.name = name;
    }
}

// Esta línea nos permite exportar nuestra clase *Utilización de Common JS para exportar mómdulos*
module.exports = MissionCommander;