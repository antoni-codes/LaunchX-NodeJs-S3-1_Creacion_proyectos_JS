
const MyMissionCommander = require('./app/MissionCommander');

const emmaMC = new MyMissionCommander('Emmanuel')
console.log(emmaMC.name);

const carloMC = new MyMissionCommander('Carlo')
console.log(carloMC.name);

const lauraMC = new MyMissionCommander('Laura')
console.log(lauraMC.name);